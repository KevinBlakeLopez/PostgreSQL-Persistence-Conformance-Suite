"""Read-only comparison of fresh-run artifacts, original recordings, and server log.

Usage: python -I verify_fresh.py <PPCS-root>
Does not contact a database or mutate repository/evidence files.
"""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
REPO = Path(sys.argv[1])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

print('Verifier interpreter:', sys.version.replace('\n', ' '))
env = json.loads((HERE / 'environment.json').read_text())
assert env['programs_completed'] is True and env['container_removed'] is True
assert env['server']['server_version_num'] == '180006'
assert 'uid=999(postgres)' in (HERE / 'server-os-user.txt').read_text()
print('Fresh server identity/version, non-root user, completion and removal recorded:', env['container'], env['server']['version'])

originals = {
    'asyncpg_commit_rollback.py': REPO / 'research/python-upstream-contribution/chk-2-asyncpg/asyncpg_commit_rollback.py',
    'psycopg_transaction_block.py': REPO / 'research/python-ecosystem-contribution-audit/psycopg_transaction_block.py',
    'psycopg_pipeline_outer_error.py': REPO / 'research/python-upstream-contribution/psycopg-pipeline-test-check/psycopg_pipeline_outer_error.py',
}
for name, source in originals.items():
    assert (HERE / name).read_bytes() == source.read_bytes()
    print('Exact script:', name, digest(HERE / name))

installs = json.loads((HERE / 'pip-install-report.json').read_text())['install']
versions = {x['metadata']['name'].lower().replace('_', '-'): x['metadata']['version'] for x in installs}
assert versions == {'asyncpg': '0.32.0', 'uvloop': '0.23.0', 'psycopg': '3.3.6', 'psycopg-binary': '3.3.6'}, versions
for x in installs:
    assert x['download_info']['url'].startswith('https://files.pythonhosted.org/') and x['download_info']['url'].endswith('.whl')
    print('PyPI wheel:', x['metadata']['name'], x['metadata']['version'], x['download_info']['archive_info']['hashes']['sha256'])

def mask_xids(text):
    return re.sub(r'pg_xact_status\(\d+\)', 'pg_xact_status(X)', text)

printed = {}
for loop in ('asyncio', 'uvloop'):
    for rep in (1, 2, 3):
        name = f'asyncpg-{loop}-rep{rep}'
        actual = (HERE / (name + '.out')).read_text()
        old = (REPO / f'research/python-upstream-contribution/chk-2-asyncpg/output/{loop}.rep{rep}.out').read_text()
        assert mask_xids(actual) == mask_xids(old), name
        arm = None
        for line in actual.splitlines():
            if line.split(':', 1)[0] in ('managed', 'explicit', 'raw', 'control'):
                arm = line.split(':', 1)[0]
            m = re.search(r'pg_xact_status\((\d+)\) (\w+)', line)
            if m:
                assert m[1] not in printed
                printed[m[1]] = (name, arm, m[2])
        print('MATCH after masking only transaction IDs:', name)

for name, old in [('psycopg-transaction', 'research/python-ecosystem-contribution-audit/psycopg_transaction_block.txt'), ('psycopg-pipeline', 'research/python-upstream-contribution/psycopg-pipeline-test-check/output/psycopg_pipeline_outer_error.out')]:
    assert (HERE / (name + '.out')).read_bytes() == (REPO / old).read_bytes(), name
    print('BYTE-IDENTICAL original/fresh stdout:', name, digest(HERE / (name + '.out')))

psql = {}
for line in (HERE / 'psql-xact-status.txt').read_text().splitlines():
    cells = line.split('|')
    if len(cells) == 5 and cells[2].isdigit():
        run, arm, xid, expected, actual = cells
        assert expected == actual
        psql[xid] = (run, arm, actual)
assert len(psql) == 24 and psql == printed
print('Independent psql check: 24/24 match; 18 aborted, 6 committed.')

sessions = defaultdict(list)
for n, line in enumerate((HERE / 'server.log').read_text().splitlines(), 1):
    m = re.match(r'.*?\[(\d+)\] app=(\S*) xid=(\d+) (LOG|ERROR|DETAIL|STATEMENT):\s+(.*)', line)
    if m:
        pid, app, xid, kind, text = m.groups()
        sessions[(pid, app)].append((n, xid, kind, text))
subjects = [(pid, app, records) for (pid, app), records in sessions.items() if app in ('repro-managed', 'repro-explicit', 'repro-raw', 'repro-control')]
assert len(subjects) == 24
for pid, app, records in subjects:
    captures = [r for r in records if r[2] == 'LOG' and 'select pg_current_xact_id()::text' in r[3]]
    assert len(captures) == 1
    xid = captures[0][1]
    assert printed[xid][1] == app.removeprefix('repro-')
    errors = [r for r in records if r[2] == 'ERROR']
    assert len(errors) == 1 and '23505:' in errors[0][3] and 'duplicate key' in errors[0][3]
    statements = [re.sub(r'^00000:\s+statement:\s*', '', r[3]) for r in records if r[2] == 'LOG' and 'statement: ' in r[3]]
    controls = [s for s in statements if re.match(r'^(BEGIN|COMMIT|ROLLBACK|SAVEPOINT|RELEASE)\b', s)]
    assert controls[-1] == ('COMMIT' if app == 'repro-raw' else 'COMMIT;')
    if app == 'repro-control':
        assert any(s.startswith('SAVEPOINT') for s in controls) and any(s.startswith('ROLLBACK TO') for s in controls)
    else:
        assert not any(s.startswith('ROLLBACK') for s in controls)
    print('Fresh log match:', printed[xid][0], app, 'pid', pid, 'xid', xid, 'controls', controls, 'lines', records[0][0], '-', records[-1][0])

psy = [(pid, records) for (pid, app), records in sessions.items() if app == 'fresh-psycopg' and any('select pg_current_xact_id()::text' in r[3] for r in records)]
assert len(psy) == 6
for pid, records in psy:
    assert any(r[2] == 'ERROR' and '23505:' in r[3] for r in records)
    controls = [r[3] for r in records if r[2] == 'LOG' and re.search(r'statement: (COMMIT|ROLLBACK|SAVEPOINT|RELEASE)\b', r[3])]
    assert controls[-1].endswith('statement: COMMIT')
print('Psycopg original-block server log: 6 caught/recovered sessions; each has unique violation and final COMMIT.')

pipe = [(pid, app, records) for (pid, app), records in sessions.items() if app.startswith('chk-pipe-')]
assert len(pipe) == 6
for pid, app, records in pipe:
    assert any(r[2] == 'ERROR' and '42703:' in r[3] and 'column "error" does not exist' in r[3] for r in records)
    statements = [r[3] for r in records if r[2] == 'LOG' and 'statement:' in r[3]]
    assert statements[-1].endswith('statement: COMMIT')
    assert not any('create table voila' in r[3] for r in records)
print('Psycopg pipeline-pattern server log: 6/6 undefined-column errors then COMMIT; no CREATE TABLE executed.')
programs = [r for r in json.loads((HERE / 'execution-commands.json').read_text()) if r.get('output', '').endswith('.out')]
assert len(programs) == 8 and all(r['returncode'] == 0 for r in programs)
print('ALL CHECKS PASSED: 8/8 standalone executions exited 0; no result discrepancies.')
