"""Fresh, isolated reproduction. Creates/removes only its own named Docker container.

Execute with the fresh virtualenv Python and -I. Requires Docker access.
No PPCS harness, repository mutation, preexisting database, or upstream mutation.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import subprocess
import sys
import time
import uuid

import psycopg

ROOT = Path(__file__).resolve().parent
PYTHON = str(ROOT / 'venv/bin/python')
IMAGE = 'postgres:18.6@sha256:74935e72241653ca55e0414067e6d8763aceb8a810eb51b452253ec3dcfc4336'
TOKEN = 'fresh-' + uuid.uuid4().hex
CONTAINER = 'ppcs-independent-' + TOKEN[6:18]
PORT = 55537
URL = f'postgresql://postgres@127.0.0.1:{PORT}/postgres'
commands = []
started = False

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def execute(args, *, output=None, env=None, timeout=90, check=True):
    begin = utc()
    p = subprocess.run(args, env=env, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    record = {'started_at_utc': begin, 'ended_at_utc': utc(), 'argv': args, 'returncode': p.returncode}
    if env is not None:
        record['DATABASE_URL'] = env['DATABASE_URL']
    if not output:
        record['stdout'] = p.stdout
    if output:
        (ROOT / output).write_text(p.stdout)
        record['output'] = output
    commands.append(record)
    (ROOT / 'execution-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if check and p.returncode:
        raise RuntimeError(f'{shlex.join(args)} failed ({p.returncode}): {p.stdout}')
    return p

def run_program(name, filename, argument=None, app=None):
    env = dict(os.environ)
    env['DATABASE_URL'] = URL + (f'?application_name={app}' if app else '')
    args = [PYTHON, '-I', str(ROOT / filename)] + ([argument] if argument else [])
    print('Running', name, flush=True)
    execute(args, output=name + '.out', env=env)

metadata = {'started_at_utc': utc(), 'client': {'python': sys.version, 'system': platform.system(), 'machine': platform.machine(), 'macos': platform.mac_ver()[0]}, 'image': IMAGE, 'container': CONTAINER, 'port': PORT, 'authentication': 'trust on disposable cluster; published only on host loopback', 'server_data': '/tmp/fresh-pg (container tmpfs)', 'server_os_user': 'postgres', 'cluster_name': TOKEN, 'script_hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')}}
(ROOT / 'environment.json').write_text(json.dumps(metadata, indent=2) + '\n')

try:
    # Non-root initdb and server. No official entrypoint and no reused data directory.
    boot = 'initdb -D /tmp/fresh-pg --username=postgres --auth=trust --encoding=UTF8 --no-locale && exec postgres -D /tmp/fresh-pg -p ' + str(PORT) + ' -k /tmp -c listen_addresses=* -c log_statement=all -c log_error_verbosity=verbose -c "log_line_prefix=%m [%p] app=%a xid=%x " -c cluster_name=' + TOKEN
    args = ['docker', 'run', '--rm', '-d', '--name', CONTAINER, '--user', 'postgres', '--read-only', '--tmpfs', '/tmp:rw,nosuid,nodev,size=256m,mode=1777', '-p', f'127.0.0.1:{PORT}:{PORT}', '--entrypoint', 'bash', IMAGE, '-c', boot]
    print('Starting new non-root PostgreSQL cluster in', CONTAINER, flush=True)
    execute(args, output='docker-start.txt')
    started = True
    ready = False
    for _ in range(60):
        p = execute(['docker', 'exec', CONTAINER, 'pg_isready', '-h', '127.0.0.1', '-p', str(PORT), '-U', 'postgres', '-d', 'postgres'], check=False, timeout=10)
        if p.returncode == 0:
            ready = True
            break
        time.sleep(0.25)
    if not ready:
        raise RuntimeError('Fresh PostgreSQL failed readiness')
    execute(['docker', 'exec', CONTAINER, 'id'], output='server-os-user.txt')
    execute(['docker', 'inspect', '--format', '{{json .Config.User}} {{json .Image}} {{json .HostConfig.Tmpfs}} {{json .HostConfig.PortBindings}}', CONTAINER], output='docker-identity.txt')
    host_errors = []
    host_con = None
    for attempt in range(40):
        try:
            host_con = psycopg.connect(URL, autocommit=True, connect_timeout=1, application_name='fresh-verifier')
            break
        except psycopg.OperationalError as exc:
            host_errors.append({'attempt': attempt + 1, 'at_utc': utc(), 'error': str(exc)})
            time.sleep(0.25)
    (ROOT / 'host-readiness.json').write_text(json.dumps(host_errors, indent=2) + '\n')
    if host_con is None:
        raise RuntimeError('Fresh server host-port readiness timed out')
    with host_con as con:
        token, version, number = con.execute("select current_setting('cluster_name'), version(), current_setting('server_version_num')").fetchone()
        if token != TOKEN or int(number) < 130000:
            raise RuntimeError('Fresh server identity/version mismatch')
        metadata['server'] = {'version': version, 'server_version_num': number, 'identity_token_verified': True, 'settings': dict(con.execute("select name,setting from pg_settings where name in ('synchronous_commit','default_transaction_isolation','statement_timeout','idle_in_transaction_session_timeout','log_statement','log_error_verbosity','port')").fetchall())}
    (ROOT / 'environment.json').write_text(json.dumps(metadata, indent=2) + '\n')
    execute([PYTHON, '-I', '-m', 'pip', 'freeze', '--all'], output='pip-freeze.txt')
    for loop in ('asyncio', 'uvloop'):
        for rep in (1, 2, 3):
            run_program(f'asyncpg-{loop}-rep{rep}', 'asyncpg_commit_rollback.py', loop)
    run_program('psycopg-transaction', 'psycopg_transaction_block.py', app='fresh-psycopg')
    run_program('psycopg-pipeline', 'psycopg_pipeline_outer_error.py', app='fresh-pipeline')

    # PostgreSQL status is also queried through psql, independent of either Python driver.
    values = []
    for path in sorted(ROOT.glob('asyncpg-*-rep*.out')):
        arm = None
        for line in path.read_text().splitlines():
            if line.split(':', 1)[0] in ('managed', 'explicit', 'raw', 'control'):
                arm = line.split(':', 1)[0]
            m = re.search(r'pg_xact_status\((\d+)\) (\w+)', line)
            if m:
                values.append((path.stem, arm, int(m[1]), m[2]))
    if len(values) != 24:
        raise RuntimeError('Expected 24 asyncpg transaction IDs')
    sqlvalues = ','.join(f"('{name}','{arm}',{xid},'{fate}')" for name, arm, xid, fate in values)
    sql = 'select run,arm,xid,expected,pg_xact_status(xid::text::xid8) as actual from (values ' + sqlvalues + ') as t(run,arm,xid,expected) order by xid;'
    (ROOT / 'psql-status-query.sql').write_text(sql + '\n')
    execute(['docker', 'exec', CONTAINER, 'psql', '-X', '-h', '127.0.0.1', '-p', str(PORT), '-U', 'postgres', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1', '-A', '-F', '|', '-c', sql], output='psql-xact-status.txt')
    print('All eight program executions completed. Independent psql check recorded.', flush=True)
    metadata['programs_completed'] = True
finally:
    if started:
        try:
            execute(['docker', 'logs', CONTAINER], output='server.log', timeout=30, check=False)
        finally:
            # --rm deletes the container, its anonymous volumes and its tmpfs data.
            stopped = execute(['docker', 'stop', '--time', '10', CONTAINER], output='docker-stop.txt', timeout=30, check=False)
            if stopped.returncode != 0:
                execute(['docker', 'rm', '-f', '-v', CONTAINER], output='docker-cleanup-fallback.txt', timeout=30)
            probe = execute(['docker', 'inspect', CONTAINER], output='docker-removed.txt', timeout=15, check=False)
            metadata['container_removed'] = probe.returncode != 0 and 'No such' in probe.stdout
            if not metadata['container_removed']:
                raise RuntimeError('Could not establish removal of fresh container')
    metadata['ended_at_utc'] = utc()
    (ROOT / 'environment.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print('Fresh server stopped and removed:', metadata.get('container_removed', False), flush=True)
